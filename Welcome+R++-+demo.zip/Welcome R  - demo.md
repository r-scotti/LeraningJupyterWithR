
<div style="text-align: center"><img width=300px src="http://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/R_logo.svg/200px-R_logo.svg.png"></div>

# R and Jupyter

This notebook is here to demonstrate the integration capabilities of R with the Jupyter Project. 
The R kernel is still young, so miss a lot of feature, but can still display inline graphincs in notebooks.

For simple comparison we reproduce here some part of the famous `demo(graphics)` command of R in the Jupyter notebook, 
Where the commend have been converted to markdown cells.

 # R demo

Here is some code which illustrates some of the differences between
R and S graphics capabilities.  Note that colors are generally specified
by a character string name (taken from the X11 rgb.txt file) and that line
textures are given similarly.  The parameter "bg" sets the background
parameter for the plot and there is also an "fg" parameter which sets
the foreground color.


```R
require(datasets)

require(grDevices); require(graphics)
```


```R
x <- stats::rnorm(50)
opar <- par(bg = "white")
plot(x, ann = FALSE, type = "n") +
abline(h = 0, col = gray(.90)) +
lines(x, col = "green4", lty = "dotted") +
points(x, bg = "limegreen", pch = 21) +
title(main = "Simple Use of Color In a Plot",
       xlab = "Just a Whisper of a Label",
       col.main = "blue", col.lab = gray(.8),
       cex.main = 1.2, cex.lab = 1.0, font.main = 4, font.lab = 3)
```


![png](output_6_0.png)





    numeric(0)



## A little color wheel.

This code just plots equally spaced hues in
a pie chart. If you have a cheap SVGA monitor (like me) you will
probably find that numerically equispaced does not mean visually
equispaced.  On my display at home, these colors tend to cluster at
the RGB primaries.  On the other hand on the SGI Indy at work the
effect is near perfect


```R
par(bg = "gray")

pie(rep(1,24), col = rainbow(24), radius = 0.9) +
title(main = "A Sample Color Wheel", cex.main = 1.4, font.main = 3) +
title(xlab = "(Use this as a test of monitor linearity)",
      cex.lab = 0.8, font.lab = 3)
```


![png](output_8_0.png)





    numeric(0)



# A scatterplot matrix
The good old Iris data (yet again)


```R
pairs(iris[1:4], main="Edgar Anderson's Iris Data", pch=21,
       bg = c("red", "green3", "blue")[unclass(iris$Species)])
```


![png](output_10_0.png)

